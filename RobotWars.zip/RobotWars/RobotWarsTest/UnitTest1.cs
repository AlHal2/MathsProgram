﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using RobotWars;
namespace RobotWarsTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Robot r = new Robot();
            Assert.AreEqual("X = 1.  Y = 3.  Direction = N", r.Instructions(1, 2, "N", "LMLMLMLMM", 7, 6));
            Assert.AreEqual("X = 5.  Y = 1.  Direction = E", r.Instructions(3, 3, "E", "MMRMMRMRRM", 7, 6));

        }
    }
}
