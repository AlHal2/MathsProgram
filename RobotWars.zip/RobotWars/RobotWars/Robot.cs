﻿using System;


namespace RobotWars
{
    public class Robot
    {
        public string Instructions(int X, int Y, string Dir, string Input, int MaxX, int MaxY)
        {
            string FinalPositionAndDirection = "";
            try
            {
                for (int i = 0; i < Input.Length; i++)
                {
                    if (Input.Substring(i, 1) == "M")
                    {
                        switch (Dir)
                        {
                            case "N":
                                Y += 1;
                                break;
                            case "E":
                                X += 1;
                                break;
                            case "W":
                                X -= 1;
                                break;
                            case "S":
                                Y -= 1;
                                break;
                        }
                    }
                    else if (Input.Substring(i, 1) == "L")
                    {
                        switch (Dir)
                        {
                            case "N":
                                Dir = "W";
                                break;
                            case "W":
                                Dir = "S";
                                break;
                            case "S":
                                Dir = "E";
                                break;
                            case "E":
                                Dir = "N";
                                break;

                        }
                    }
                    else if (Input.Substring(i, 1) == "R")
                    {
                        switch (Dir)
                        {
                            case "N":
                                Dir = "E";
                                break;
                            case "E":
                                Dir = "S";
                                break;
                            case "S":
                                Dir = "W";
                                break;
                            case "W":
                                Dir = "N";
                                break;
                        }
                    }
                    else
                    {
                        return "Directions must be L R or M.";
                    }
                }
                if (X < 0 || X > MaxX)
                {
                    FinalPositionAndDirection = "X = " + X.ToString() + ".  Y = " + Y.ToString() + ".  Direction = " + Dir + "  Robot has gone out play";
                }
                if (Y < 0 || Y > MaxY)
                {
                    FinalPositionAndDirection = "X = " + X.ToString() + ".  Y = " + Y.ToString() + ".  Direction = " + Dir + "  Robot has gone out play";
                }
                FinalPositionAndDirection = "X = " + X.ToString() + ".  Y = " + Y.ToString() + ".  Direction = " + Dir;
                return FinalPositionAndDirection;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return ex.Message;
            }

        }
    }

}
