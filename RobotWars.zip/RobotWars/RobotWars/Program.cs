﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotWars
{
    class Program
    {
        static void Main(string[] args)
        {
            Robot r = new Robot();
            Console.WriteLine(r.Instructions(1, 2, "N", "LMLMLMLMM", 7, 6));

        }
    }
}
