﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace MovieApp.Controllers
{
    public class ValuesController : ApiController
    {
        List<Movie> movie = new List<Movie>();
        // GET api/values
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/values/5
        public Movie Get(string Title)
        {
            //return "value";
           
            return movie.Where(x => x.Title == Title).FirstOrDefault();
        }

        // POST api/values
        //public void Post([FromBody]string value)
        [HttpPost]
        public void Post([FromUri]int ID,int UserID, string Title,int Rating)
        {
            using (WebAPIDBEntities1 context = new WebAPIDBEntities1())
            {
                MovieRating mv = new MovieRating
                {
                    ID=ID,
                    UserID=UserID,
                    Title= Title,
                    Rating=Rating
                };
                context.MovieRatings.Add(mv);
                context.SaveChanges();
            }
        }

        // PUT api/values/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE api/values/5
        public void Delete(int id)
        {
        }
    }
}
