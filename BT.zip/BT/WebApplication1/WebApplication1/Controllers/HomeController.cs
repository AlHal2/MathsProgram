﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        [HttpGet]
        public ActionResult Cards()
        {
            //C.GetScore(C.Deck);
            return View();
        }
        [HttpPost]
        public ActionResult Cards(CardModel C)
        {
            if (C.GetScore(C.Deck) > 0)
            {
                Models.CardModel NewModel = new Models.CardModel { Deck = C.GetScore(C.Deck).ToString() };
                return View("Score", NewModel);
            }
            else
            {
                return View("Error");
            }
        }
    }
}