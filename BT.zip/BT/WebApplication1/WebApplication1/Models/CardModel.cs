﻿using System;
namespace WebApplication1.Models
{
    public class CardModel
    {
        public string Deck { get; set; }
        public int GetScore(string s)
        {
            try
            {
                int score = 0;
                int totalScore = 0;
                string individualCard = "";
                bool oneJokerFound = false;
                bool twoJokersFound = false;
                int number;
                if (s == null)
                {
                    return 0;
                }
                else if (s == "")
                {
                    return 0;
                }
                for (int i = 2; i < s.Length; i += 3)
                {
                    if (s.Substring(i, 1) != ",")
                    {
                        throw new Exception("Deck must consist of two digit card followed by comma");
                    }
                }
                s = s.Replace(",", "");
                do
                {
                    if (int.TryParse(s.Substring(0, 1), out number))
                    {
                        score = int.Parse(s.Substring(0, 1));
                    }
                    else if (s.Substring(0, 1) == "T")
                    {
                        score = 10;
                    }
                    else if (s.Substring(0, 1) == "J" && s.Substring(0, 2) != "JR")
                    {
                        score = 11;
                    }
                    else if (s.Substring(0, 1) == "Q")
                    {
                        score = 12;
                    }
                    else if (s.Substring(0, 1) == "K")
                    {
                        score = 13;
                    }
                    else if (s.Substring(0, 1) == "A")
                    {
                        score = 14;
                    }
                    else if (s.Substring(0, 2) == "JR")
                    {
                        if (twoJokersFound == true)
                        {
                            throw new Exception("More than two jokers");
                            //totalScore = 0;
                            //break;
                        }
                        score = 0;
                        if (oneJokerFound == true)
                        {
                            oneJokerFound = false;
                            twoJokersFound = true;
                        }
                        else
                        {
                            oneJokerFound = true;
                            twoJokersFound = false;
                        }
                    }
                    else
                    {
                        throw new Exception("Invalid card");
                        //totalScore = 0;
                        //break;
                    }
                    switch (s.Substring(1, 1))
                    //switch (s.Substring(i + 1, 1))
                    {
                        case "C":
                            break;
                        case "D":
                            score = score * 2;
                            break;
                        case "H":
                            score = score * 3;
                            break;
                        case "S":
                            score = score * 4;
                            break;
                        case "R":
                            score = 0;
                            break;
                        default:
                            throw new Exception("Invalid card");
                            //totalScore = 0;
                            //break;
                    }
                    totalScore += score;

                    individualCard = s.Substring(0, 2);
                    //individualCard = s.Substring(i, 2);
                    //if (individualCard != "JR")
                    //{
                    s = s.Remove(0, 2);
                    //}

                    s.Replace(",,", ",");
                    if (s.Length > 1 && s.Substring(0, 1) == ",")
                    {
                        s = s.Remove(0, 1);
                    }
                    if (s.Contains(individualCard) && individualCard != "JR")
                    {
                        throw new Exception("Duplicate card " + individualCard);
                        //totalScore = 0;
                        //break;
                    }

                } while (s.Length > 0);
                if (oneJokerFound == true)
                    totalScore = totalScore * 2;
                else if (twoJokersFound == true)
                {
                    totalScore = totalScore * 4;
                }
                return totalScore;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
    }
}