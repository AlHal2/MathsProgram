﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WebApplication1;
using WebApplication1.Controllers;
using WebApplication1.Models;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            CardModel C = new CardModel();
            C.Deck = "2C,AS";
            Assert.AreEqual(58, C.GetScore(C.Deck));
            C.Deck = "JR,JR,2C,AS";
            Assert.AreEqual(232, C.GetScore(C.Deck));
            C.Deck = "2C,AS,JR,JR";
            Assert.AreEqual(232, C.GetScore(C.Deck));

        }
        [TestMethod]
        public void DuplicateTests()
        {
            CardModel C = new CardModel();
            C.Deck = "2C,AS,JR,JR";
            Assert.AreEqual(232, C.GetScore(C.Deck));
            C.Deck = "JR,2C,AS,JR,6H,JR";
            Assert.ThrowsException<Exception>(() => C.GetScore(C.Deck));
            C.Deck = "2C,AS,JR,JR,AS";
            Assert.ThrowsException<Exception>(() => C.GetScore(C.Deck));
        }
        [TestMethod]
        public void EmptyTest()
        {
            CardModel C = new CardModel();
            C.Deck = "";
            Assert.AreEqual(0, C.GetScore(C.Deck));
            
        }
        [TestMethod]
        public void NoCommaTest()
        {
            CardModel C = new CardModel();
            C.Deck = "2C,AS,JR,JRAS";
            Assert.ThrowsException<Exception>(() => C.GetScore(C.Deck));
            C.Deck = "2C/AS,JR,JR.AS";
            Assert.ThrowsException<Exception>(() => C.GetScore(C.Deck));
        }
        [TestMethod]
        public void InvalidTwoDigitCardTest()
        {
            CardModel C = new CardModel();
            C.Deck = "AC,AS,JR,JRAS";
            Assert.ThrowsException<Exception>(() => C.GetScore(C.Deck));
            C.Deck = "2C,AS,JR,DR.AS";
            Assert.ThrowsException<Exception>(() => C.GetScore(C.Deck));
        }

    }
}
