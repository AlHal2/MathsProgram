﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            using (StreamWriter sw = new StreamWriter(@"D:\OneDrive\Documents\Tests\Betway\Results.txt"))
            {
                Stopwatch stopwatch = new Stopwatch();
                var rnd = new Random();
                    int[] numbers = (from i in Enumerable.Range(0, 100000000)
                                     select rnd.Next(0, 100000000)).ToArray();
                    Array.Sort(numbers);
                stopwatch.Start();
                    Console.WriteLine(Program.CountNumbers(numbers, 10000));
                stopwatch.Stop();
                sw.WriteLine("Elapsed time for first method in milliseconds " + stopwatch.ElapsedMilliseconds);
                stopwatch.Start();
                Console.WriteLine(Program.CountNumbers2(numbers, 10000));
                stopwatch.Stop();
                sw.WriteLine("Elapsed time for second method in milliseconds " + stopwatch.ElapsedMilliseconds);
                //Console.WriteLine(Program.CountNumbers(new int[] { 4 }, 4));
                //Console.WriteLine(Program.CountNumbers2(new int[] { 4 }, 4));

            }
            Environment.Exit(0);
        }
        public static int CountNumbers(int[] sortedArray, int lessThan)
        {
            int Counter = 0;
            //throw new NotImplementedException("Waiting to be implemented.");
            for (int i = 0; i < sortedArray.Length; i++)
            {
                if (sortedArray[i] < lessThan)
                {
                    Counter += 1;
                }
                else
                {
                    return Counter;

                }
            }
            return Counter;
        }
        public static int CountNumbers2(int[] sortedArray, int lessThan)
        {
            //based on https://www.geeksforgeeks.org/count-smaller-equal-elements-sorted-array/
            int MinimumNumber = 0;
            int MaximumNumber = sortedArray.Length-1;
            int Counter = 0;
            while (MinimumNumber < MaximumNumber)
            {
                Counter = MinimumNumber + (MaximumNumber - MinimumNumber) / 2;

                // Check if key is present in sortedArrayay
                if (sortedArray[Counter] <lessThan)
                {
                    // If duplicates are present it returns
                    // the position of last element
                    while (sortedArray[Counter + 1] < lessThan && Counter + 1 < MaximumNumber)
                        Counter++;
                    break;
                }

                // If key is smaller, ignore MaximumNumber half
                else if (sortedArray[Counter] > lessThan)
                    MaximumNumber = Counter;

                // If key is greater, ignore MinimumNumber half
                else
                    MinimumNumber = Counter + 1;
            }

            // If key is not found in sortedArrayay then it will be
            // before Counter
            while (sortedArray[Counter] > lessThan)
                Counter--;

            // Return Counter + 1 because of 0-based indexing
            // of sortedArrayay
            return Counter + 1;
        }
    }

}


