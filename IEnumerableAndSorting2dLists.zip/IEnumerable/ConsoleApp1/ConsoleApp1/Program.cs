﻿using System;
using System.Collections; //Needed for IEnumerator to work
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {

            List<int> ages = new List<int>();
            ages.Add(10);
            ages.Add(20);
            ages.Add(30);
            ages.Add(40);
            ages.Add(50);
            ages.Reverse();
            foreach (int age in ages)
            {
                Console.WriteLine(age);
            }

            IEnumerable<int> age_IEnumerable = (IEnumerable<int>)ages;
            foreach (int age in age_IEnumerable.Reverse())
            {

                Console.WriteLine(age);
            }
            //IEnumerator<int> age_IEnumerator = ages.GetEnumerator();
            //while (age_IEnumerator.MoveNext())
            //{

            //    Console.WriteLine(age_IEnumerator.Current);
            //}
            Console.WriteLine(ages.Count());
            //Source https://stackoverflow.com/questions/558304/can-anyone-explain-ienumerable-and-ienumerator-to-me
            Console.WriteLine("***** Fun with IEnumerable / IEnumerator *****\n");
            //Without IEnumerable, this code gives error message: foreach statement cannot operate on variables of type 'Garage' because 'Garage' does not contain a public definition for 'GetEnumerator'	ConsoleApp1 D:\Documents\IEnumerable\ConsoleApp1\ConsoleApp1\Program.cs	16	Active
            //
            Garage carLot = new Garage();
            // Hand over each car in the collection?
            foreach (Car c in carLot)
            {
                Console.WriteLine("{0} is going {1} MPH",
                c.PetName, c.CurrentSpeed);
            }

            //Manually work with IEnumerator.
            //IEnumerator i = carLot.GetEnumerator();
            //i.Reset();
            //foreach (Car c in carLot)
            //{
            //    i.MoveNext();
            //    Car myCar = (Car)i.Current;
            //    Console.WriteLine("{0} is going {1} MPH", myCar.PetName, myCar.CurrentSpeed);
            //}
            //Alternatively:


            //IEnumerator i = carLot.GetEnumerator();
            //i.MoveNext();
            //Car myCar = (Car)i.Current;
            //Console.WriteLine("{0} is going {1} MPH", myCar.PetName, myCar.CurrentSpeed);

            //Use list and class instead of a 2d array when you need to sort.
            //see https://msdn.microsoft.com/en-us/library/bb534966(v=vs.110).aspx for information on orderby method
            //Enumerable.OrderBy<TSource, TKey> Method (IEnumerable<TSource>, Func<TSource, TKey>)
            //Parameters
            //source
            //Type: System.Collections.Generic.IEnumerable<TSource>
            //A sequence of values to order.

            //keySelector
            //Type: System.Func<TSource, TKey>
            //A function to extract a key from an element.

            //Return Value
            //Type: System.Linq.IOrderedEnumerable<TSource>
            //An IOrderedEnumerable<TElement> whose elements are sorted according to a key.

            //Type Parameters
            //TSource
            //The type of the elements of source.

            //TKey
            //The type of the key returned by keySelector.
            //Remarks
            //This method is implemented by using deferred execution. The immediate return value is an object that stores all the information that is required to perform the action.The query represented by this method is not executed until the object is enumerated either by calling its GetEnumerator method directly or by using foreach in Visual C# or For Each in Visual Basic.

            //To order a sequence by the values of the elements themselves, specify the identity function(x => x in Visual C# or Function(x) x in Visual Basic) for keySelector.

            //Two methods are defined to extend the type IOrderedEnumerable<TElement>, which is the return type of this method.These two methods, namely ThenBy and ThenByDescending, enable you to specify additional sort criteria to sort a sequence. ThenBy and ThenByDescending also return an IOrderedEnumerable<TElement>, which means any number of consecutive calls to ThenBy or ThenByDescending can be made.
            var rows = new List<Company>();
            //string[] data = new string[];
            using (StreamWriter sw = new StreamWriter(@"D:\Documents\MyPrograms\IEnumerable\DsInfo2.csv"))
            {
                using (StreamWriter sw2 = new StreamWriter(@"D:\Documents\MyPrograms\IEnumerable\DsInfo3.csv"))
                {
                        foreach (var line in File.ReadAllLines(@"D:\Documents\MyPrograms\IEnumerable\DsInfo.csv"))
                        {
                            var data = line.Split(',');
                            rows.Add(new Company { Code = data[0], Name = data[1], Code2 = data[2], Currency = data[3] });
                        }
                    var sortBy = rows.OrderBy(qqqf => qqqf.Code);  ///qqqf chosen arbitrarily
                    var sortBy2 = sortBy.OrderBy(f => f.Name);
                    foreach (Company c in sortBy)
                        sw.WriteLine(c.Code + "," + c.Name + "," + c.Code2 + "," + c.Currency);
                    foreach (Company c in sortBy2)
                        sw2.WriteLine(c.Code + "," + c.Name + "," + c.Code2 + "," + c.Currency);
                }
            }
           

        }


    }
    class Company
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string Code2 { get; set; }
        public string Currency { get; set; }
    }
}
