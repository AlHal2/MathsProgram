﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Car
    {
        //private string PName;
        //private int CurSpeed;

        string _PetName;
        public string PetName
        {
            get { return _PetName; }
            set { _PetName = value; }
        }

        int _CurrentSpeed;
        public int CurrentSpeed
        {
            get { return _CurrentSpeed; }
            set { _CurrentSpeed = value; }
        }

        public Car(string PassedPetName, int PassedCurrentSpeed)
            {
            //PassedPetName = PetName;
            //PassedCurrentSpeed = CurrentSpeed;
            PetName = PassedPetName;
            CurrentSpeed = PassedCurrentSpeed;
            }
    }
}
