﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace ChicagoBulls
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                ConvertHeightToCentimetres ch = new ConvertHeightToCentimetres();
                
                //string line2 = "";
                var rows = new List<Players>();
                using (StreamWriter sw = new StreamWriter(@"D:\Documents\Tests\ExecView\Test2\ChicagoBulls\chicago-bulls.json"))
                {

                    foreach (var line in File.ReadAllLines(@"D:\Documents\Tests\ExecView\Test2\ChicagoBulls\chicago-bulls.csv"))
                    {
                        //line2 = line.Replace(@"""", "");
                        var data = line.Replace(@"""", "").Split(',');
                        int number;
                        
                        if (int.TryParse(data[0], out number))
                        {
                            rows.Add(new Players
                            {
                                ID = int.Parse(data[0]),
                                Position = data[1],
                                Number = int.Parse(data[2]),
                                Country = data[3],
                                FirstName = data[5],
                                LastName = data[4],
                                OrigHeight = data[6],
                                Weight = data[7],
                                University = data[8],
                                PPG = decimal.Parse(data[9]),
                                Height=ch.calculate(int.Parse(data[6].Substring(0, 1)), int.Parse(data[6].Substring(4, 3).Trim()))


                            });
                        }
                    }
                    var sortBy = rows.OrderByDescending(q => q.PPG);
                    sw.WriteLine("{");
                    sw.WriteLine("    " + (char)34 + "Players" + (char)34 + ": [");
                    foreach (Players p in sortBy)
                    {
                        sw.WriteLine("{");
                        sw.WriteLine("        " + (char)34 + "Id" + (char)34 + ": " + p.ID + ",");
                        sw.WriteLine("        " + (char)34 + "Position" + (char)34 + ": " + p.Position + ",");
                        sw.WriteLine("        " + (char)34 + "Number" + (char)34 + ": " + p.Number + ",");
                        sw.WriteLine("        " + (char)34 + "Country" + (char)34 + ": " + p.Country + ",");
                        sw.WriteLine("        " + (char)34 + "Name" + (char)34 + ": " + p.LastName+ ", "+p.FirstName + ",");
                        sw.WriteLine("        " + (char)34 + "Height" + (char)34 + ": " + p.OrigHeight + ",");
                        sw.WriteLine("        " + (char)34 + "Weight" + (char)34 + ": " + p.Weight + ",");
                        sw.WriteLine("        " + (char)34 + "University" + (char)34 + ": " + p.University + ",");
                        sw.WriteLine("        " + (char)34 + "PPG" + (char)34 + ": " + p.PPG );
                        if (sortBy.Last().PPG == p.PPG)
                        {
                            sw.WriteLine("}],");
                        }
                        else
                        {
                            sw.WriteLine("},");
                        }
                    }

                    //I had to go online to look up the list manipulation syntax whcih follows.
                    sw.WriteLine("    "+(char)34 + "Average PPG" + (char)34 + ": "+Math.Round( sortBy.Average(item => item.PPG),2)+",");
                    sw.WriteLine("    "+(char)34 + "Leaders" + (char)34 + ":[{");
                    sw.WriteLine("        " + (char)34 + "Gold" + (char)34 + ": " + (char)34 + sortBy.First().LastName+", "+ sortBy.First().FirstName + (char)34+",");
                    sw.WriteLine("        " + (char)34 + "PPG" + (char)34 + ": "+ (char)34 + sortBy.First().PPG);
                    sw.WriteLine("},");
                    sw.WriteLine("{");
                    sw.WriteLine("        " + (char)34 + "Silver" + (char)34 + ": " + (char)34 + sortBy.ElementAt(1).LastName + ", " + sortBy.ElementAt(1).FirstName + (char)34 + ",");
                    sw.WriteLine("        " + (char)34 + "PPG" + (char)34 + ": " + (char)34 + sortBy.ElementAt(1).PPG);
                    sw.WriteLine("},");
                    sw.WriteLine("{");
                    sw.WriteLine("        " + (char)34 + "Bronze" + (char)34 + ": " + (char)34 + sortBy.ElementAt(2).LastName + ", " + sortBy.ElementAt(2).FirstName + (char)34 + ",");
                    sw.WriteLine("        " + (char)34 + "PPG" + (char)34 + ": " + (char)34 + sortBy.ElementAt(2).PPG);
                    sw.WriteLine("}],");
                    sw.WriteLine("        " + (char)34  + (char)34 +": {");

                    var DistinctItems = sortBy.Select(x => x.Position).Distinct().ToList();
                    
                    foreach (string s in DistinctItems)
                    {
                        if (DistinctItems.Last() == s)
                        {
                            sw.WriteLine("    " + (char)34 + s + (char)34 + ": " + sortBy.Count(pos => pos.Position == s));
                        }
                        else
                        {
                            sw.WriteLine("    " + (char)34 + s + (char)34 + ": " + sortBy.Count(pos => pos.Position == s) + ",");
                        }
                        //sw.WriteLine("    " + (char)34 + "PG: " + (char)34 + sortBy.Count(pos => pos.Position=="PG"));
                    }
                    //sw.WriteLine("    " +  ": {");
                    
                    sw.WriteLine("    " +  "},");
                    sw.WriteLine("    " + (char)34 + "Average Height" + (char)34 + ": " + (char)34 + sortBy.Average(item => item.Height) + (char)34);
                    sw.WriteLine("}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }

        }

}
    class Players
    {
        public int ID { get; set; }
        public string Position { get; set; }
        public int Number { get; set; }
        public string Country { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public decimal Height { get; set; }
        public string OrigHeight { get; set; }
        public string Weight { get; set; }
        public string University { get; set; }
        public decimal PPG { get; set; }
    }
    class ConvertHeightToCentimetres
    {
        public decimal calculate(int Feet, int Inches)
        {
            return (Feet*30.48m) + (Inches*2.54m);
        }
    }

}
