﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace MathsProg
{
    delegate bool myDelegate(int CheckThisNumber);
    struct CheckPrimes
    {
        public void PrintListFromBeginning(int MaxNumberToTry)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(@"D:\Documents\MathsPrograms\Prime1.csv", false))
                {
                    int CheckThisNumber = 2;
                    int Counter = 2;
                    for (CheckThisNumber = 2; CheckThisNumber <= MaxNumberToTry; CheckThisNumber++)
                    {
                        Counter = 2;
                        do
                        {
                            if (CheckThisNumber % Counter == 0)
                            {
                                break;
                            }
                            else
                            {

                            }
                            Counter += 1;
                        } while (Counter * Counter < CheckThisNumber);
                        if (Counter * Counter > CheckThisNumber)
                        {
                            sw.WriteLine(CheckThisNumber);
                            Counter = 2;
                        }
                        else
                        {
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }
 
        public void PrintListFromEnd(int MaxNumberToTry, int MinNumberToTry)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(@"D:\Documents\MathsPrograms\Prime2.csv", false))
                {
                    int CheckThisNumber = 2;
                    int Counter = 2;
                    for (CheckThisNumber = MaxNumberToTry; CheckThisNumber >= MinNumberToTry; CheckThisNumber--)
                    {
                        Counter = 2;
                        do
                        {
                            if (CheckThisNumber % Counter == 0)
                            {
                                break;//CheckThisNumber not prime number
                            }
                            else
                            {

                            }
                            Counter += 1;
                        } while (Counter * Counter < CheckThisNumber);
                        if (Counter * Counter > CheckThisNumber)
                        {
                            sw.WriteLine(CheckThisNumber);
                            Counter = 2;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }
        public Boolean CheckIfNumberIsPrime(int CheckThisNumber)
        {
            int Counter = 2;

                Counter = 2;
                //for (Counter = 2; Counter*Counter <= CheckThisNumber; Counter++)
                do
                {
                    if (CheckThisNumber % Counter == 0)
                    {
                        return false;
                    }
                    else
                    {

                    }
                    Counter += 1;
                } while (Counter * Counter < CheckThisNumber);
                if (Counter * Counter > CheckThisNumber)
                {
                    return true;
                }
                else
                {
                    return false;
                }

        }
        public int GCDRecursive(int a, int b)
        {
            //article on http://www.vcskicks.com/euclidean-gcd.php
            if (a == 0)
                return b;
            if (b == 0)
                return a;

            if (a > b)
                return GCDRecursive(a % b, b);
            else
                return GCDRecursive(a, b % a);
        }
    }

}
