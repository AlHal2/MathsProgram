﻿namespace MathsProg
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmdPrime = new System.Windows.Forms.Button();
            this.cmdPythagoras = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cmdPrime
            // 
            this.cmdPrime.Location = new System.Drawing.Point(1, 38);
            this.cmdPrime.Name = "cmdPrime";
            this.cmdPrime.Size = new System.Drawing.Size(121, 23);
            this.cmdPrime.TabIndex = 0;
            this.cmdPrime.Text = "Prime Number Test";
            this.cmdPrime.UseVisualStyleBackColor = true;
            this.cmdPrime.Click += new System.EventHandler(this.cmdPrime_Click);
            // 
            // cmdPythagoras
            // 
            this.cmdPythagoras.Location = new System.Drawing.Point(1, 119);
            this.cmdPythagoras.Name = "cmdPythagoras";
            this.cmdPythagoras.Size = new System.Drawing.Size(75, 23);
            this.cmdPythagoras.TabIndex = 1;
            this.cmdPythagoras.Text = "Pythagrean Triples";
            this.cmdPythagoras.UseVisualStyleBackColor = true;
            this.cmdPythagoras.Click += new System.EventHandler(this.cmdPythagoras_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.cmdPythagoras);
            this.Controls.Add(this.cmdPrime);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button cmdPrime;
        private System.Windows.Forms.Button cmdPythagoras;
    }
}

