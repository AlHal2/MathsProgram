﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace MathsProg
{
    class CloseToANumber
    {
        public void FindNearNumbers( decimal NumberToApproximate)
        {
            int NumberCount = 0;
            decimal[,] AryNumbers = new decimal[40000000,3];
            for (decimal Numerator=1;Numerator<2000;Numerator++)
            {
                for (decimal Denominator=1;Denominator<=2000;Denominator++)
                {
                    AryNumbers[NumberCount,0] = Numerator;
                    AryNumbers[NumberCount, 1] = Denominator;
                    AryNumbers[NumberCount, 2] = (Numerator / Denominator) - NumberToApproximate;
                    NumberCount += 1;
                }
            }
            decimal[,] AryNumbersReDimmed = new decimal[NumberCount,3];
            for (int i = 0; i < NumberCount; ++i)
            {
                for (int j = 0; j < 3; ++j)
                {
                    AryNumbersReDimmed[i, j] = AryNumbers[i, j];
                }
            }
            AryNumbers = AryNumbersReDimmed;

            decimal[,] sortedByThirdElement = AryNumbers.OrderBy(x => x[2]);
            using (StreamWriter sw = new StreamWriter(@"D:\Documents\MathsPrograms\CloseToANumber.csv", false))
            {
                for (int i = 0; i< NumberCount; i++)
                {
                    if (sortedByThirdElement[i, 2] < 0.00001m && sortedByThirdElement[i, 2] > -0.00001m)
                    {
                        sw.WriteLine(sortedByThirdElement[i, 0] + "," + sortedByThirdElement[i, 1] + "," + sortedByThirdElement[i, 2]);
                    }
                }
            }
            Environment.Exit(0);
        }

    }

    public static class MultiDimensionalArrayExtensions
    {
        /// <summary>
        ///   Orders the two dimensional array by the provided key in the key selector.
        /// </summary>
        /// <typeparam name="T">The type of the source two-dimensional array.</typeparam>
        /// <param name="source">The source two-dimensional array.</param>
        /// <param name="keySelector">The selector to retrieve the column to sort on.</param>
        /// <returns>A new two dimensional array sorted on the key.</returns>
        public static T[,] OrderBy<T>(this T[,] source, Func<T[], T> keySelector)
        {
            return source.ConvertToSingleDimension().OrderBy(keySelector).ConvertToMultiDimensional();
        }
        /// <summary>
        ///   Orders the two dimensional array by the provided key in the key selector in descending order.
        /// </summary>
        /// <typeparam name="T">The type of the source two-dimensional array.</typeparam>
        /// <param name="source">The source two-dimensional array.</param>
        /// <param name="keySelector">The selector to retrieve the column to sort on.</param>
        /// <returns>A new two dimensional array sorted on the key.</returns>
        public static T[,] OrderByDescending<T>(this T[,] source, Func<T[], T> keySelector)
        {
            return source.ConvertToSingleDimension().OrderByDescending(keySelector).ConvertToMultiDimensional();
        }
        /// <summary>
        ///   Converts a two dimensional array to single dimensional array.
        /// </summary>
        /// <typeparam name="T">The type of the two dimensional array.</typeparam>
        /// <param name="source">The source two dimensional array.</param>
        /// <returns>The repackaged two dimensional array as a single dimension based on rows.</returns>
        private static IEnumerable<T[]> ConvertToSingleDimension<T>(this T[,] source)
        {
            T[] arRow;

            for (int row = 0; row < source.GetLength(0); ++row)
            {
                arRow = new T[source.GetLength(1)];

                for (int col = 0; col < source.GetLength(1); ++col)
                    arRow[col] = source[row, col];

                yield return arRow;
            }

        }
        /// <summary>
        ///   Converts a collection of rows from a two dimensional array back into a two dimensional array.
        /// </summary>
        /// <typeparam name="T">The type of the two dimensional array.</typeparam>
        /// <param name="source">The source collection of rows to convert.</param>
        /// <returns>The two dimensional array.</returns>
        private static T[,] ConvertToMultiDimensional<T>(this IEnumerable<T[]> source)
        {
            T[,] twoDimensional;
            T[][] arrayOfArray;
            int numberofColumns;

            arrayOfArray = source.ToArray();
            numberofColumns = (arrayOfArray.Length > 0) ? arrayOfArray[0].Length : 0;
            twoDimensional = new T[arrayOfArray.Length, numberofColumns];

            for (int row = 0; row < arrayOfArray.GetLength(0); ++row)
                for (int col = 0; col < numberofColumns; ++col)
                    twoDimensional[row, col] = arrayOfArray[row][col];

            return twoDimensional;
        }
    }
}
