﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;
using System.IO;
namespace MathsProg
{
    
    class PowerSharingDigits
    {
        public void Evaluate()
        {
            try
            {
                BigInteger k = 0;
                using (StreamWriter sw = new StreamWriter(@"D:\Documents\MathsPrograms\PowerSharingDigits.csv"))
                {
                    for (int i = 2; i <= 100; i++)
                    {


                        for (int j = 2; j <= 100; j++)
                        {
                            k = BigInteger.Pow(i, j);
                            if (i.ToString().Length == 1)
                            {
                                if ("0" + i.ToString() == "0" + k.ToString().Substring(k.ToString().Length - 1, 1))
                                {
                                    sw.WriteLine(i.ToString() + " to the power of " + j.ToString() + " = " + k);
                                    break;
                                }
                            }
                            else if (i.ToString().Length == 2)
                            {
                                if (i == 28 && j == 30)
                                {
                                }
                                if ((i.ToString().Substring(i.ToString().Length - 2, 2)) == k.ToString().Substring(k.ToString().Length - 2, 2))
                                {
                                    sw.WriteLine(i.ToString() + " to the power of " + j.ToString() + " = " + k);
                                    break;
                                }
                            }
                            else if (i.ToString().Length == 3)
                            {
                                if ((i.ToString().Substring(i.ToString().Length - 3, 3)) == k.ToString().Substring(k.ToString().Length - 3, 3))
                                {
                                    sw.WriteLine(i.ToString() + " to the power of " + j.ToString() + " = " + k);
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }
    }
}
