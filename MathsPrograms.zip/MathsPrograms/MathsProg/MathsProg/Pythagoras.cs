﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace MathsProg
{

    class Pythagoras
    {
        int _Smallest;
        public int Smallest
        {
            get { return _Smallest; }
            set { _Smallest = value; }
        }
        int _Medium;
        public int Medium
        {
            get { return _Medium; }
            set { _Medium = value; }
        }
        int _Biggest;
        public int Biggest
        {
            get { return _Biggest; }
            set { _Biggest = value; }
        }
        string _Comment;
        public string Comment
        {
            get { return _Comment; }
            set { _Comment = value; }
        }
 

    }
}
