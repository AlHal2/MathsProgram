﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace MathsProg
{
    class Pythagoras
    {
        public void FindAllTriples()
        {
            try
            {
                int Small = 0;
                int Med = 0;
                int Big = 0;
                CheckPrimes cp = new CheckPrimes();
                using (StreamWriter sw = new StreamWriter(@"D:\Documents\MathsPrograms\Pythagoras.csv", false))
                {
                    for (Small = 2; Small <= 100; Small++)
                        
                    {
                        for (Med = Small+1; Med <= 1000; Med++)
                        {
                            
                            {
                                for (Big = Small+1; Big <= 1000; Big++)
                                    if ((Small * Small) + (Med * Med) == (Big * Big))
                                    {
                                        //cp.CheckIfNumberIsPrime(Small);
                                        if (cp.CheckIfNumberIsPrime(Small) == true || cp.CheckIfNumberIsPrime(Med) == true || cp.CheckIfNumberIsPrime(Big) == true)
                                        {
                                            sw.WriteLine(Small + "," + Med + "," + Big + ","+"At least one prime");

                                        }
                                        else if (cp.GCDRecursive(Small,Med)==1 && cp.GCDRecursive(Small, Big) == 1 &&  cp.GCDRecursive(Med, Big) == 1)
                                        {
                                            sw.WriteLine(Small + "," + Med + "," + Big + "," + "Numbers have no highest common factor");
                                        }
                                        else
                                        {
                                            sw.WriteLine(Small + "," + Med + "," + Big);
                                        }
                                    }
                            }
                        }
                    }
                }
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }
    }
}
