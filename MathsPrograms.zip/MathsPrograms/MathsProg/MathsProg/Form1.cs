﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
namespace MathsProg
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cmdPrime_Click(object sender, EventArgs e)
        {
            Button b1 = new Button();
            b1.Text = "Click me";
            b1.Left = 50;
            b1.Top = 50;
            b1.Text = "Enter the number below which you want all primes";
            b1.Click += new EventHandler(FindThePrimes);//EventHandler is pre-defined delegate.  Right click and select goto definition
            //Without the delegate I could not trigger an event for button added at runtime
            this.Controls.Add(b1);
            TextBox t1 = new TextBox();
            t1.Name = "txtEnterPrime";
            t1.Left = 150;
            t1.Top = 150;
            t1.Size = new Size(100, 25);
            t1.KeyPress += new KeyPressEventHandler(TextBox1_KeyPress);
            this.Controls.Add(t1);


        }
        private void FindThePrimes(object sender, EventArgs e)
        {
            Stopwatch s = new Stopwatch();
            s.Start();
            //necessary to handle dynamically created text box
            TextBox i = this.Controls["txtEnterPrime"] as TextBox;
            int MaxNumber = int.Parse(i.Text);
            //if (MaxNumber % 2==0)
            //{
            //    CheckPrimes a = new CheckPrimes();
            //    a.PrintListFromBeginning(MaxNumber/2);
            //    a.PrintListFromEnd(MaxNumber, (MaxNumber / 2) + 1);
            //    //GetListOfPrimesFromEnd b = new GetListOfPrimesFromEnd();
            //    //b.PrintList(MaxNumber,( MaxNumber/2)+1);
            //}
            //else
            //{
            //    CheckPrimes a = new CheckPrimes();
            //    a.PrintListFromBeginning((MaxNumber+1) / 2);
            //    //GetListOfPrimesFromEnd b = new GetListOfPrimesFromEnd();
            //    a.PrintListFromEnd(MaxNumber, (MaxNumber+3) / 2 );

            //}
            Task t1 = Task.Run(() =>
            {
                CheckPrimes a = new CheckPrimes();
                a.PrintListFromBeginning(MaxNumber / 2);
            });



            Task t2 = Task.Run(() =>
            {
                CheckPrimes b = new CheckPrimes();
                b.PrintListFromEnd(MaxNumber, (MaxNumber + 3) / 2);
            });

            s.Stop();
            //Console.WriteLine(s.ElapsedMilliseconds);
            //Console.ReadKey();
            Environment.Exit(0);
        }
        private void TextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar);//!char.IsLetterOrDigit(e.KeyChar);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cmdPythagoras_Click(object sender, EventArgs e)
        {
            Pythagoras p = new Pythagoras();
            p.FindAllTriples();
            
            
        }
    }
}
