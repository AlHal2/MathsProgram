﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;
using System.IO;
namespace MathsProg
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void cmdPrime_Click(object sender, EventArgs e)
        {
            Button b1 = new Button();
            b1.Text = "Click me";
            b1.Left = cmdPrime.Left+cmdPrime.Width; 
            b1.Top = cmdPrime.Top;
            b1.Text = "Enter the number below which you want all primes";
            b1.Click += new EventHandler(FindThePrimes);//EventHandler is pre-defined delegate.  Right click and select goto definition
            //Without the delegate I could not trigger an event for button added at runtime
            this.Controls.Add(b1);
            TextBox t1 = new TextBox();
            t1.Name = "txtEnterPrime";
            t1.Left = b1.Left+b1.Width+10;
            t1.Top = b1.Top;
            t1.Size = new Size(100, 25);
            t1.KeyPress += new KeyPressEventHandler(TextBox1_KeyPress);
            this.Controls.Add(t1);


        }
        private void FindThePrimes(object sender, EventArgs e)
        {
            Stopwatch s = new Stopwatch();
            s.Start();
            //necessary to handle dynamically created text box
            TextBox i = this.Controls["txtEnterPrime"] as TextBox;
            int MaxNumber = int.Parse(i.Text);
            //if (MaxNumber % 2==0)
            //{
            //    CheckPrimes a = new CheckPrimes();
            //    a.PrintListFromBeginning(MaxNumber/2);
            //    a.PrintListFromEnd(MaxNumber, (MaxNumber / 2) + 1);
            //    //GetListOfPrimesFromEnd b = new GetListOfPrimesFromEnd();
            //    //b.PrintList(MaxNumber,( MaxNumber/2)+1);
            //}
            //else
            //{
            //    CheckPrimes a = new CheckPrimes();
            //    a.PrintListFromBeginning((MaxNumber+1) / 2);
            //    //GetListOfPrimesFromEnd b = new GetListOfPrimesFromEnd();
            //    a.PrintListFromEnd(MaxNumber, (MaxNumber+3) / 2 );

            //}
            if (MaxNumber % 2 == 0)
            {
                Task t1 = Task.Run(() =>
            {
                CheckPrimes a = new CheckPrimes();
                a.PrintListFromBeginning(MaxNumber / 2);

               
            });

                Task t2 = Task.Run(() =>
                {
                    CheckPrimes b = new CheckPrimes();
                    b.PrintListFromEnd(MaxNumber, (MaxNumber + 3) / 2);
                });
            }
            else
            {
                Task t1 = Task.Run(() =>
                {
                    CheckPrimes a = new CheckPrimes();
                    a.PrintListFromBeginning((MaxNumber)+1 / 2);


                });

                Task t2 = Task.Run(() =>
                {
                    CheckPrimes b = new CheckPrimes();
                    b.PrintListFromEnd(MaxNumber, (MaxNumber + 3) / 2);
                });
            }
            s.Stop();
            //Console.WriteLine(s.ElapsedMilliseconds);
            //Console.ReadKey();
            Environment.Exit(0);
        }
        private void TextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar);//!char.IsLetterOrDigit(e.KeyChar);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void cmdPythagoras_Click(object sender, EventArgs e)
        {
            //Pythagoras p = new Pythagoras();
            // p.FindAllTriples();

            FindAllTriples();
        }
        public void FindAllTriples()
        {
            try
            {
                List<Pythagoras> pt = new List<Pythagoras>();
                int Small = 0;
                int Med = 0;
                int Big = 0;
                CheckPrimes cp = new CheckPrimes();

                for (Small = 2; Small <= 100; Small++)

                {
                    for (Med = Small + 1; Med <= 1000; Med++)
                    {

                        {
                            for (Big = Small + 1; Big <= 1000; Big++)
                                if ((Small * Small) + (Med * Med) == (Big * Big))
                                {
                                    //Example using delegate
                                    myDelegate dg = new myDelegate(cp.CheckIfNumberIsPrime);
                                    Pythagoras p = new Pythagoras();
                                    p.Smallest = Small;
                                    p.Medium = Med;
                                    p.Biggest = Big;
                                    if (dg(Small) == true || dg(Med) == true || dg(Big) == true)
                                    {
                                         p.Comment = "At least one prime";
                                    }
                                    else if (cp.GCDRecursive(Small,
                                        Med) == 1 && cp.GCDRecursive(Small, Big) == 1 && cp.GCDRecursive(Med, Big) == 1)
                                    {
                                        p.Comment = "Numbers have no highest common factor";
                                    }
                                    else
                                    {
                                        p.Comment = "";
                                    }
                                    pt.Add(p);
                                }
                        }
                    }
                }
                using (StreamWriter sw = new StreamWriter(@"D:\Documents\MathsPrograms\Pythagoras.csv", false))
                {
                    foreach (Pythagoras p in pt)
                    {
                        sw.WriteLine(p.Smallest + "," + p.Medium + "," + p.Biggest + "," + p.Comment);

                    }
                    Environment.Exit(0);
                }
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
            }
        }

        private void cmdPowerSharing_Click(object sender, EventArgs e)
        {
            PowerSharingDigits psd = new PowerSharingDigits();
            psd.Evaluate();
            Environment.Exit(0);
        }

        private void cmdFindNearNumber_Click(object sender, EventArgs e)
        {
            //CloseToANumber fn = new CloseToANumber();

            Task t1 = Task.Run(() =>
            {
                CloseToANumber fn = new CloseToANumber();
                fn.FindNearNumbers(3.14159265358979323846m);//pi


            });

            //fn.FindNearNumbers(3.14159265358979323846m);//pi
        }
    }
}
