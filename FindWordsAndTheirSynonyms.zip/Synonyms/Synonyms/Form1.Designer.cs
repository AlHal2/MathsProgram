﻿namespace Synonyms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cmdFindSynonyms = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.cmdFindString = new System.Windows.Forms.Button();
            this.cmdFindWords = new System.Windows.Forms.Button();
            this.txtOutputDirectory = new System.Windows.Forms.TextBox();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbDrives = new System.Windows.Forms.ComboBox();
            this.treeviewFolders = new System.Windows.Forms.TreeView();
            this.lstFiles = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(182, 29);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(120, 20);
            this.textBox1.TabIndex = 1;
            // 
            // cmdFindSynonyms
            // 
            this.cmdFindSynonyms.Location = new System.Drawing.Point(182, 55);
            this.cmdFindSynonyms.Name = "cmdFindSynonyms";
            this.cmdFindSynonyms.Size = new System.Drawing.Size(120, 23);
            this.cmdFindSynonyms.TabIndex = 2;
            this.cmdFindSynonyms.Text = "Find Synonyms";
            this.cmdFindSynonyms.UseVisualStyleBackColor = true;
            this.cmdFindSynonyms.Click += new System.EventHandler(this.cmdFindSynonyms_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(179, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(220, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Enter Words separated by a | to find synonym";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Enter Text String";
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(19, 94);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 95);
            this.listBox2.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(19, 29);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 7;
            // 
            // cmdFindString
            // 
            this.cmdFindString.Location = new System.Drawing.Point(19, 55);
            this.cmdFindString.Name = "cmdFindString";
            this.cmdFindString.Size = new System.Drawing.Size(120, 23);
            this.cmdFindString.TabIndex = 8;
            this.cmdFindString.Text = "Spellcheck";
            this.cmdFindString.UseVisualStyleBackColor = true;
            this.cmdFindString.Click += new System.EventHandler(this.cmdFindString_Click);
            // 
            // cmdFindWords
            // 
            this.cmdFindWords.Location = new System.Drawing.Point(427, 55);
            this.cmdFindWords.Name = "cmdFindWords";
            this.cmdFindWords.Size = new System.Drawing.Size(75, 23);
            this.cmdFindWords.TabIndex = 9;
            this.cmdFindWords.Text = "Find Words";
            this.cmdFindWords.UseVisualStyleBackColor = true;
            this.cmdFindWords.Click += new System.EventHandler(this.cmdFindWords_Click);
            // 
            // txtOutputDirectory
            // 
            this.txtOutputDirectory.Location = new System.Drawing.Point(557, 29);
            this.txtOutputDirectory.Name = "txtOutputDirectory";
            this.txtOutputDirectory.Size = new System.Drawing.Size(534, 20);
            this.txtOutputDirectory.TabIndex = 10;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "folder-closed.png");
            this.imageList1.Images.SetKeyName(1, "file.png");
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(554, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(368, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Select directory to search.  Type manually or use the directory browser below";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(182, 94);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(320, 154);
            this.checkedListBox1.TabIndex = 14;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 276);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(65, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Select Drive";
            // 
            // cmbDrives
            // 
            this.cmbDrives.FormattingEnabled = true;
            this.cmbDrives.Location = new System.Drawing.Point(18, 307);
            this.cmbDrives.Name = "cmbDrives";
            this.cmbDrives.Size = new System.Drawing.Size(121, 21);
            this.cmbDrives.TabIndex = 16;
            this.cmbDrives.SelectedIndexChanged += new System.EventHandler(this.cmbDrives_SelectedIndexChanged);
            // 
            // treeviewFolders
            // 
            this.treeviewFolders.Location = new System.Drawing.Point(193, 307);
            this.treeviewFolders.Name = "treeviewFolders";
            this.treeviewFolders.Size = new System.Drawing.Size(309, 188);
            this.treeviewFolders.TabIndex = 17;
            this.treeviewFolders.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeviewFolders_AfterSelect);
            // 
            // lstFiles
            // 
            this.lstFiles.FormattingEnabled = true;
            this.lstFiles.Location = new System.Drawing.Point(557, 309);
            this.lstFiles.Name = "lstFiles";
            this.lstFiles.Size = new System.Drawing.Size(534, 186);
            this.lstFiles.TabIndex = 18;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1103, 517);
            this.Controls.Add(this.lstFiles);
            this.Controls.Add(this.treeviewFolders);
            this.Controls.Add(this.cmbDrives);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtOutputDirectory);
            this.Controls.Add(this.cmdFindWords);
            this.Controls.Add(this.cmdFindString);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cmdFindSynonyms);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button cmdFindSynonyms;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button cmdFindString;
        private System.Windows.Forms.Button cmdFindWords;
        private System.Windows.Forms.TextBox txtOutputDirectory;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbDrives;
        private System.Windows.Forms.TreeView treeviewFolders;
        private System.Windows.Forms.ListBox lstFiles;
    }
}

