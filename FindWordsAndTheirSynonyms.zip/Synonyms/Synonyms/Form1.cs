﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Word = Microsoft.Office.Interop.Word;
using System.IO;
using System.IO.Packaging; //Had to add reference to windowsbase assembly
using System.Xml.Linq;
using System.Xml;
namespace Synonyms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            foreach (var Drives in Environment.GetLogicalDrives())
            {
                DriveInfo DriveInf = new DriveInfo(Drives);
                if (DriveInf.IsReady == true)
                {
                    cmbDrives.Items.Add(DriveInf.Name);
                }
            }
        }
        
        private void cmdFindSynonyms_Click(object sender, EventArgs e)
        {
            Word.Application application = default(Word.Application);
            object objNull = null;
            object objFalse = false;
            object objLanguage = Word.WdLanguageID.wdEnglishUS;

            try
            {
                application = new Word.Application();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening Microsoft Word; {ex.Message}");
                return;
            }
            checkedListBox1.Items.Clear();
           

            //checkedListBox1.DataSource = null;
            List<string> result = textBox1.Text.Split('|').ToList();
            //txtSynonyms.Text = "";

            foreach (string s in result)
            {
                checkedListBox1.Items.Add(s.Trim());
                Word.SynonymInfo info = application.get_SynonymInfo(s, ref objLanguage);

                int iMeanings = (int)info.MeaningCount;

                if (iMeanings > 0)
                {
                    var items = (from item in ((Array)(object)info.MeaningList).Cast<string>()
                                 let synonyms = ((Array)(object)info.get_SynonymList(item)).Cast<string>()
                                 from synonym in synonyms
                                 select new { DisplayMember = synonym, ValueMember = synonym }).ToList();
                    items.ToList();
                    foreach (var i in items)
                    {
                        //txtSynonyms.Text = txtSynonyms.Text + "|" + i.DisplayMember.ToString();
                        checkedListBox1.Items.Add(i.DisplayMember.ToString());
                    }
                    //listBox1.DataSource = items;

                }
                else
                {
                    //listBox1.DataSource = new[] { new { DisplayMember = "NONE", ValueMember = "NONE" } };
                }
                checkedListBox1.DisplayMember = "DisplayMember";
                checkedListBox1.ValueMember = "ValueMember";
                Destroy(info);
            }
            
            application.Quit(ref objFalse, ref objNull, ref objNull);
            Destroy(application);
        }
        private void Destroy(object objCom)
        {
            try
            {
                while (Marshal.ReleaseComObject(objCom) > 0) {; }
            }
            finally
            {
                objCom = null;
            }
        }

        private void cmdFindString_Click(object sender, EventArgs e)
        {
            //Give spellcheck suggestions
            Word.Application application = default(Word.Application);

            try
            {
                application = new Word.Application();
                application.Documents.Add();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error opening Microsoft Word; {ex.Message}");
                return;
            }

            listBox2.DataSource = null;
            Word.SpellingSuggestions suggestions = application.GetSpellingSuggestions(textBox2.Text, null, true);

            if (suggestions.Count > 0)
            {
                var items = (from item in suggestions.Cast<Word.SpellingSuggestion>()
                             select new { DisplayMember = item.Name, ValueMember = item }).ToList();

                listBox2.DataSource = items;
            }
            else
            {
                listBox2.DataSource = new[] { new { DisplayMember = "NONE", ValueMember = "NONE" } };
            }
            listBox2.DisplayMember = "DisplayMember";
            listBox2.ValueMember = "ValueMember";

            Destroy(suggestions);
            application.Quit(false, null, null);
            Destroy(application);
        }
        public static string ParagraphText(XElement e)
        {
            XNamespace w = e.Name.Namespace;
            return e
                   .Elements(w + "r")
                   .Elements(w + "t")
                   .StringConcatenate(element => (string)element);
        }
        private void cmdFindWords_Click(object sender, EventArgs e)
        {
            try
            {
                string DRow = "";
                DirectoryInfo dir = new DirectoryInfo(txtOutputDirectory.Text);
                using (StreamWriter sw = new StreamWriter(txtOutputDirectory.Text + "\\Results.lst"))
                    
                {
                    foreach (FileInfo f in dir.GetFiles())
                    {
                        if (f.Extension == ".csv" || f.Extension == ".txt")
                            using (StreamReader sr = new StreamReader(f.FullName))
                            {
                                while (sr.Peek() >= 0)
                                {
                                    DRow = sr.ReadLine().ToUpper();
                                    //foreach (CheckedListBox item in checkedListBox1.Items)
                                    foreach (Object item in checkedListBox1.CheckedItems)
                                            {
                                                if (DRow.Contains(item.ToString().ToUpper()))
                                                {
                                                    sw.WriteLine(item.ToString() + "," + f.FullName + "," + DRow);
                                                }
                                            }
                                }
                            }
                        else if (f.Extension == ".docx")  //can only use for docx format
                        {
                            const string documentRelationshipType =
                "http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument";
                            const string stylesRelationshipType =
                              "http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles";
                            const string wordmlNamespace =
                              "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
                            XNamespace w = wordmlNamespace;

                            XDocument xDoc = null;
                            XDocument styleDoc = null;
                            using (Package wdPackage = Package.Open(f.FullName, FileMode.Open, FileAccess.Read))
                            {
                                PackageRelationship docPackageRelationship =
                                  wdPackage.GetRelationshipsByType(documentRelationshipType).FirstOrDefault();
                                if (docPackageRelationship != null)
                                {
                                    Uri documentUri = PackUriHelper.ResolvePartUri(new Uri("/", UriKind.Relative),
                                      docPackageRelationship.TargetUri);
                                    PackagePart documentPart = wdPackage.GetPart(documentUri);

                                    //  Load the document XML in the part into an XDocument instance.  
                                    xDoc = XDocument.Load(XmlReader.Create(documentPart.GetStream()));

                                    //  Find the styles part. There will only be one.  
                                    PackageRelationship styleRelation =
                                      documentPart.GetRelationshipsByType(stylesRelationshipType).FirstOrDefault();
                                    if (styleRelation != null)
                                    {
                                        Uri styleUri =
                                          PackUriHelper.ResolvePartUri(documentUri, styleRelation.TargetUri);
                                        PackagePart stylePart = wdPackage.GetPart(styleUri);

                                        //  Load the style XML in the part into an XDocument instance.  
                                        styleDoc = XDocument.Load(XmlReader.Create(stylePart.GetStream()));
                                    }
                                }
                            }

                            string defaultStyle =
                                (string)(
                                    from style in styleDoc.Root.Elements(w + "style")
                                    where (string)style.Attribute(w + "type") == "paragraph" &&
                                          (string)style.Attribute(w + "default") == "1"
                                    select style
                                ).First().Attribute(w + "styleId");

                            // Find all paragraphs in the document.  
                            var paragraphs =
                                from para in xDoc
                                             .Root
                                             .Element(w + "body")
                                             .Descendants(w + "p")
                                let styleNode = para
                                                .Elements(w + "pPr")
                                                .Elements(w + "pStyle")
                                                .FirstOrDefault()
                                select new
                                {
                                    ParagraphNode = para,
                                    StyleName = styleNode != null ?
                                        (string)styleNode.Attribute(w + "val") :
                                        defaultStyle
                                };

                            // Retrieve the text of each paragraph.  
                            var paraWithText =
                                from para in paragraphs
                                select new
                                {
                                    ParagraphNode = para.ParagraphNode,
                                    StyleName = para.StyleName,
                                    Text = ParagraphText(para.ParagraphNode)
                                };

                            // Following is the new query that retrieves all paragraphs  
                            // that have specific text in them.  
                            foreach (Object item in checkedListBox1.CheckedItems)
                                     {



                                        var helloParagraphs =
                                        from para in paraWithText
                                        where para.Text.ToUpper().Contains(item.ToString().ToUpper())
                                        select new
                                        {
                                            ParagraphNode = para.ParagraphNode,
                                            StyleName = para.StyleName,
                                            Text = para.Text
                                        };

                                        foreach (var p in helloParagraphs)
                                            sw.WriteLine("StyleName:{0} >{1}<>{2}<", item.ToString(), f.FullName, p.Text);
                            }

                        }
                    }

                }
                Environment.Exit(0);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        
        }
    
        private void Form1_Load(object sender, EventArgs e)
        {

        }
          private void cmbDrives_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbDrives.SelectedItem != null)
            {
                ListDirectory(treeviewFolders, cmbDrives.SelectedItem.ToString());
            }
        }
        // ListDirectory Function (Recursive Approach):
        // 
        private void ListDirectory(TreeView treeView, string path)
        {
            treeView.Nodes.Clear();
            var rootDirectoryInfo = new DirectoryInfo(path);
            treeView.Nodes.Add(CreateDirectoryNode(rootDirectoryInfo));
        }
        // Create Directory Node
        // 
        private static TreeNode CreateDirectoryNode(DirectoryInfo directoryInfo)
        {
            var directoryNode = new TreeNode(directoryInfo.Name);
            try
            {
                foreach (var directory in directoryInfo.GetDirectories())
                    directoryNode.Nodes.Add(CreateDirectoryNode(directory));
            }
            catch (Exception ex)
            {
                UnauthorizedAccessException Uaex = new UnauthorizedAccessException();
                if (ex == Uaex)
                {
                    MessageBox.Show(Uaex.Message);
                }
            }
            return directoryNode;
        }

    
        // PopulateListBox Function
        // 
        private void PopulateListBox(ListBox lsb, string Folder)
        //private void PopulateListBox(ListBox lsb, string Folder, string FileType)
        {
            try
            {
                DirectoryInfo dinfo = new DirectoryInfo(Folder);
                //FileInfo[] Files = dinfo.GetFiles(FileType);
                FileInfo[] Files = dinfo.GetFiles();
                foreach (FileInfo file in Files)
                {
                    lsb.Items.Add(file.Name);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while attempting to load the file. The error is:"
                                + System.Environment.NewLine + ex.ToString() + System.Environment.NewLine);
            }
        }

        private void lstFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstFiles.SelectedItem != null)
            {
                //do smt here!
                MessageBox.Show(lstFiles.SelectedItem.ToString());
            }
        }

        private void treeviewFolders_AfterSelect(object sender, TreeViewEventArgs e)
        {
            lstFiles.Items.Clear();
            lstFiles.Refresh();
            //PopulateListBox(lstFiles, treeviewFolders.SelectedNode.FullPath.ToString(), "*.pdf");
            PopulateListBox(lstFiles, treeviewFolders.SelectedNode.FullPath.ToString());
            txtOutputDirectory.Text = treeviewFolders.SelectedNode.FullPath.ToString().Replace("\\\\","\\");
        }
    }
    [StructLayout(LayoutKind.Sequential)]
    public struct SHFILEINFO
    {
        public IntPtr hIcon;
        public int iIcon;
        public uint dwAttributes;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
        public string szDisplayName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)]
        public string szTypeName;
    };

    class NativeMethods
    {
        public const uint SHGFI_ICON = 0x100;
        public const uint SHGFI_LARGEICON = 0x0; // 'Large icon
        public const uint SHGFI_SMALLICON = 0x1; // 'Small icon

        [DllImport("shell32.dll")]
        public static extern IntPtr SHGetFileInfo(string pszPath, uint dwFileAttributes, ref SHFILEINFO psfi, uint cbSizeFileInfo, uint uFlags);
    }
    public static class LocalExtensions
    {
        public static string StringConcatenate(this IEnumerable<string> source)
        {
            StringBuilder sb = new StringBuilder();
            foreach (string s in source)
                sb.Append(s);
            return sb.ToString();
        }

        public static string StringConcatenate<T>(this IEnumerable<T> source,
            Func<T, string> func)
        {
            StringBuilder sb = new StringBuilder();
            foreach (T item in source)
                sb.Append(func(item));
            return sb.ToString();
        }

        public static string StringConcatenate(this IEnumerable<string> source, string separator)
        {
            StringBuilder sb = new StringBuilder();
            foreach (string s in source)
                sb.Append(s).Append(separator);
            return sb.ToString();
        }

        public static string StringConcatenate<T>(this IEnumerable<T> source,
            Func<T, string> func, string separator)
        {
            StringBuilder sb = new StringBuilder();
            foreach (T item in source)
                sb.Append(func(item)).Append(separator);
            return sb.ToString();
        }
    }
}
