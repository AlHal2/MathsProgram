﻿using System;

using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
namespace GlobalAerospace
{
    public partial class Form1 : Form
    {
        public DateTime FirstClickTime = new DateTime(2011, 1, 1, 1, 1, 1, 1);
        public DateTime SecondClickTime = new DateTime(2011, 1, 1, 1, 1, 1, 1);
        public DateTime ThirdClickTime = new DateTime(2011, 1, 1, 1, 1, 1, 1);
        public DateTime FourthClickTime = new DateTime(2011, 1, 1, 1, 1, 1, 1);
        TimeSpan timeDiff1;
        TimeSpan timeDiff2;
        TimeSpan timeDiff3;
        TimeSpan timeDiff1Now;
        public string FirstKey = "";
        public string SecondKey = "";
        public string ThirdKey = "";
        public string FourthKey = "";
        public DateTime StartTime;
        public DateTime EndTime;
        public int Keystrokes = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            StartTime = DateTime.Now;
            using (StreamWriter sw = new StreamWriter(@"D:\OneDrive\Documents\Tests\GlobalAerospaceOldMobileKeyboard\MobKeyboard4\Results.txt", false))
            {
                sw.WriteLine("Started at " + StartTime);
            }
        }
        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            textBox1.Text = Regex.Replace(textBox1.Text, @"[\d-]", "");
        }
        private string ReturnKeys(string KeyPressed)
        {
            
            string OutputKey = "";
            switch (KeyPressed)
            {
                case "2":
                    OutputKey = "abc";
                    break;

                case "3":
                    OutputKey = "def";
                    break;
                case "4":
                    OutputKey = "ghi";
                    break;
                case "5":
                    OutputKey = "jkl";
                    break;
                case "6":
                    OutputKey = "mno";
                    break;
                case "7":
                    OutputKey = "pqrs";
                    break;
                case "8":
                    OutputKey = "tuv";
                    break;
                case "9":
                    OutputKey = "wxyz";
                    break;
                case "0":
                    OutputKey = " ";
                    break;
                case "#":
                    OutputKey = "#";
                    break;
                case "*":
                    OutputKey = "*";
                    break;

                default:
                    OutputKey = "";
                    break;
            }
                    return OutputKey;
            
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                using (StreamWriter sw = new StreamWriter(@"D:\OneDrive\Documents\Tests\GlobalAerospaceOldMobileKeyboard\MobKeyboard4\Results.txt", true))
                {
                    
                    
                
                Keystrokes += 1;
                textBox1.Text = Regex.Replace(textBox1.Text, @"[\d-]", "");
                FourthKey = ThirdKey;
                FourthClickTime = ThirdClickTime;
                ThirdKey = SecondKey;
                ThirdClickTime = SecondClickTime;
                SecondKey = FirstKey;
                SecondClickTime = FirstClickTime;
                FirstKey = e.KeyChar.ToString();
                FirstClickTime = DateTime.Now;
                string LetterToDisplay = "";
                timeDiff1Now = DateTime.Now - FirstClickTime;
                timeDiff1 = FirstClickTime - SecondClickTime;
                timeDiff2 = SecondClickTime - ThirdClickTime;
                timeDiff3 = ThirdClickTime - FourthClickTime;
                int NumberOfClicks = 0;
                if (FirstKey != SecondKey)
                {
                    LetterToDisplay = ReturnKeys(FirstKey).Substring(0, 1);
                    NumberOfClicks = 1;
                }
                else if (FirstKey == SecondKey && timeDiff1.TotalMilliseconds >= 500)
                {
                    LetterToDisplay = ReturnKeys(FirstKey).Substring(0, 1);
                    NumberOfClicks = 1;
                }
                else if (SecondKey == ThirdKey && timeDiff2.TotalMilliseconds < 500 && ThirdKey == FourthKey && timeDiff3.TotalMilliseconds >= 500)
                {
                    LetterToDisplay = ReturnKeys(SecondKey).Substring(2, 1);
                    NumberOfClicks = 3;
                    //textBox1.Text.Remove(textBox1.Text.Length - 1, 1);
                }
                else if (SecondKey == ThirdKey && timeDiff2.TotalMilliseconds < 500 && ThirdKey == FourthKey && timeDiff3.TotalMilliseconds < 500)
                {
                    LetterToDisplay = ReturnKeys(SecondKey).Substring(3, 1);
                    NumberOfClicks = 4;
                    //textBox1.Text.Remove(textBox1.Text.Length - 2, 2);
                }
                else if (FirstKey == SecondKey && timeDiff1.TotalMilliseconds < 500 && SecondKey != ThirdKey)
                {
                    LetterToDisplay = ReturnKeys(FirstKey).Substring(1, 1);
                    NumberOfClicks = 2;
                    //textBox1.Text.Remove(textBox1.Text.Length -1, 1);
                }
                else if (FirstKey == SecondKey && timeDiff1.TotalMilliseconds < 500 && SecondKey == ThirdKey && timeDiff2.TotalMilliseconds >= 500)
                {
                    LetterToDisplay = ReturnKeys(FirstKey).Substring(1, 1);
                    NumberOfClicks =2;
                    //textBox1.Text.Remove(textBox1.Text.Length - 1, 1);
                }
                else if (FirstKey == SecondKey && timeDiff1.TotalMilliseconds < 500 && SecondKey == ThirdKey && timeDiff2.TotalMilliseconds < 500)
                {
                    LetterToDisplay = ReturnKeys(FirstKey).Substring(2, 1);
                    NumberOfClicks = 3;
                    //textBox1.Text.Remove(textBox1.Text.Length - 2, 2);
                }
                else
                {
                    LetterToDisplay = ReturnKeys(FirstKey).Substring(0, 1);
                    NumberOfClicks = 1;
                }
                //if (timeDiff1Now.TotalMilliseconds >= 500)
                //{
                if (NumberOfClicks >1)
                {
                    textBox1.Text = textBox1.Text.Remove(textBox1.Text.Length -  1,  1);
                    //textBox1.Text = textBox1.Text.Remove(0, 1);
                }
                
                textBox1.Text = textBox1.Text + LetterToDisplay;
                sw.WriteLine(e.KeyChar);
                textBox1.Text= Regex.Replace(textBox1.Text, @"[\d-]", "");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            EndTime = DateTime.Now;
            using (StreamWriter sw = new StreamWriter(@"D:\OneDrive\Documents\Tests\GlobalAerospaceOldMobileKeyboard\MobKeyboard4\Results.txt", true))
            {
                sw.WriteLine("Ended at   " + EndTime);
                sw.WriteLine("Duration" + (EndTime - StartTime));
                sw.WriteLine("keystrokes" + (Keystrokes));
            }
        }
    }
}
