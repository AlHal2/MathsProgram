﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q2
{
    class Program
    {
        static void Main(string[] args)
        {

            List<int> Arr1 =GenerateRandomNumbers(1000);

        }
        static List<int> GenerateRandomNumbers(int index)
        {
            List<int> Arr2 = new List<int>();
            Random rnd = new Random(1000);
            for (int i = 0; i < index; i++)
            {
                
                Arr2.Add( rnd.Next(1,3));  //result is strictly less than specified maximum
                if (Arr2[i] == 2)
                {
                    return Arr2;
                }
            }
            return Arr2;
        }
    }
}
