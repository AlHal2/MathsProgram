﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class Program
    {
        static void Main(string[] args)
        {
            int []Arr1= CreateCollection();
            int []Arr2=SwitchElements(Arr1,4);
            int Element64 = LotsOfSwitches(Arr1);
        }
        static int[] CreateCollection()
        {
            int[] Arr = new int[100];
            for (int i=0;i<Arr.Length;i++)
            {
                Arr[i]= -1;
            }
            return Arr;
        }
        static int[] SwitchElements(int[] Arr,int index)
        {
            int[] Arr2 = new int[100];
            for (int i = 1; i < Arr2.Length; i++)
            {
                if (i%index==0)
                {
                    if (Arr2[i - 1] == -1)
                    {
                        Arr2[i - 1] = 1;
                    }
                    else
                    {
                        Arr2[i - 1] = -1;
                    }
                }
            }
            return Arr2;
        }
        static int LotsOfSwitches(int[] Arr3)
        {
            for (int Counter=1;Counter<101;Counter++)
            {
                SwitchElements(Arr3, Counter);

            }
            return Arr3[63];
        }
    }
}
